package com.lightcone.webviewdemo2;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

public class WebViewDemo extends Activity implements OnClickListener {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        // Add Click listeners for all buttons
        View firstButton = findViewById(R.id.button1);
        firstButton.setOnClickListener(this);
        View secondButton = findViewById(R.id.button2);
        secondButton.setOnClickListener(this);
    }

	public void onClick(View v) {
		switch(v.getId()){
        case R.id.button1:
            Intent j = new Intent(this, Webscreen.class);
        j.putExtra(com.lightcone.webviewdemo2.Webscreen.URL, 
            "http://its.vip.gatech.edu");
        startActivity(j);
        break;
        
        case R.id.button2:
            Intent k = new Intent(this, Webscreen.class);
        k.putExtra(com.lightcone.webviewdemo2.Webscreen.URL, 
            "http://www.google.com");
        startActivity(k);
        break;      
    }
		
	}
}