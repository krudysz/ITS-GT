package com.lightcone.webviewdemo2;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Log;

//class HelloWebViewClient extends WebViewClient {
   // @Override
    //public boolean shouldOverrideUrlLoading(WebView view, String url) {
       // view.loadUrl(url);
        //return true;
    //}
//}
public class Webscreen extends Activity {
	
	public static final String URL = "";
	private static final String TAG = "Class Webscreen";
	//private WebView wset;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.webscreen);
        String turl = getIntent().getStringExtra(URL);
        Log.i(TAG, "Recipe url = "+turl);
        
        WebView webview = new WebView(this);
        setContentView(webview);
        webview.getSettings().setBuiltInZoomControls(true);
        webview.setWebViewClient(new WebViewClient());
        //webview.setInitialScale(1);
        
        //wset.WebViewClient(new WebViewClient());
     //wset = webview.getSettings();
     //wset.setBuiltInZoomControls(true);

        // Simplest usage: An exception won't be thrown if there is a page-load error
        webview.loadUrl(turl); 
    }
}

