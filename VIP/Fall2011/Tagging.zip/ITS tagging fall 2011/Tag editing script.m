
close all force,clear all,clear classes,clc
%----------------------------------------------------%
% Database
 
host     = 'localhost';
 
user     = 'root';
password = 'csip';
dbName = 'its';
 
% JDBC Parameters
jdbcString = sprintf('jdbc:mysql://%s/%s', host, dbName);
jdbcDriver = 'com.mysql.jdbc.Driver';
 
% Set this to the path to your MySQL Connector/J JAR
%javaaddpath('/home/gte269x/mysql-connector-java-5.1.18/mysql-connector-java-5.1.18-bin.jar')
 
% Create the database connection object
dbConn = database(dbName, user , password, jdbcDriver, jdbcString);
 
% Check to make sure that we successfully connected
if isconnection(dbConn)
 
    exec(dbConn, 'use its;');
 
tic
unwanted=[];
for i=1:480;
 
    a=exec(dbConn,['select name from tags where id =',num2str(i),';']);
 
    Qfetch=fetch(a);
 
    id{i}=Qfetch.Data;
    
 
    b=exec(dbConn,['select id from tags where name regexp',strcat(char(39),id{i}{1},char(39)),'AND id>0;']);
 
    Rfetch=fetch(b);
 
    sameword{i}=Rfetch.Data;
    
unwanted=[unwanted; cell2mat(sameword{i}(2:end))];
end
 
for j = 1:486
update = exec(dbConn, ['update tags set use_checktest=NULL where id =',num2str(j),';']);
end
 
for j = 1:length(unwanted)
update = exec(dbConn, ['update tags set use_checktest=0 where id =',num2str(unwanted(j)),';']);
end
 
%Manual inspection part to ignore term not related to DSP
tags = [4,9,13,16,17,19,20,21,22,23,26,27,28,31,33,34,38,37,42,45,48,50,52,57,60,61,62,69,74,76,77,84,92,94,100,101,103,107,115,123,128,129,135,138,141,142,151,154,157,158,163,164,165,168,169,173,180,186,190,191,192,193,196,202,203,206,208,211,219,226,227,230,232,234,237,241,243,245,246,248,251,257,260,262,273,277,281,282,283,284,285,291,292,294,296,300,302,306,307,310,313,316,317,318,322,329,333,336,340,343,349,351,353,354];
%I inserted these below from the previous list on the facebook message
% tags=[3 4 5 6 7 8 9 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 38 39 41 42 45 50 52 54 55 57 58 59 60 61 62 65 66 67 68 69 72 73 74 76 77 81 82 83 84 85 86 87 88 89 90 91 92 94 100];
% tags=cat(2, tags, 100 + [1 2 3 5 7 15 23 24 26 27 28 29 31 32 33 34 35 36 37 38 40 42 43 48 50 51 52 53 54 55 57 58 59 60 61 62 63 64 65 66 67 68 69 72 74 75 76 7781 82 83 84 85 86 87 88 89 94]);
% tags=cat(2, tags, 200 + [2 3 4 6 8 9 10 11 13 14 16 18 19 20 21 23 24 26 27 28 29 30 31 32 33 34 35 36 37 41 43 44 45 46 47 48 49 51 52 53 55 56 57 58 59 60 61 62 71 72 73 77 78 79 80 81 82 83 84 85 89 91 92 93 94 95 96 97 99]);
% tags=cat(2, tags, 300 + [2 3 6 7 9 10 13 16 17 18 22 23 24 25 26 28 29 30 31 31 33 34 35 36 37 38 39 40 41 42 43 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 82 83 84 85 86 89 90 91 92 93 94 95 96 97 98 99]);
% tags=cat(2, tags, 400 +[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 33 34 35 36 37 38 39 40 41 43 44 45 47 48 49 50 51 52 53 54 55 56 58 59 60 61 62 63 64 65 66 67 68 69 70 71 72 73 74 75 76 77 78 79 80 81 84 85 86])
for i = 1:length(tags)
xx = tags(i);
xx2 = num2str(xx);
update = exec(dbConn, ['update tags set use_check=0 where id =',num2str(xx),';']);
end
 
 toc
    % --- OPTION 2 ----%
 
    %result = get(fetch(exec(dbConn, 'SELECT 1')), 'Data');
 
    %disp(result);
else
 
    disp(sprintf('Connection failed: %s', dbConn.Message));
end
 
% Close the connection so we don't run out of MySQL threads
close(dbConn);
