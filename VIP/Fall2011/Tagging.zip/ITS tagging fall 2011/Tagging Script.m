close all force,clear all,clear classes,clc
%----------------------------------------------------%
% Database
host     = 'localhost';
user     = 'root';
password = 'csip';
dbName   = 'its';

% JDBC Parameters
jdbcString = sprintf('jdbc:mysql://%s/%s', host, dbName);
jdbcDriver = 'com.mysql.jdbc.Driver';

% Set this to the path to your MySQL Connector/J JAR
%javaaddpath('/home/gte269x/mysql-connector-java-5.1.18/mysql-connector-java-5.1.18-bin.jar')

% Create the database connection object
dbConn = database(dbName, user , password, jdbcDriver, jdbcString);

% Check to make sure that we successfully connected
if isconnection(dbConn) 
    tic%begin stopwatch
    exec(dbConn, 'use its;');
%current=exec(dbConn, 'select name from tags where use_check is null;');
current=exec(dbConn, 'select name from tags;');%acquire tag names
current1=fetch(current);
current2=current1.Data;
%tagIDs=exec(dbConn, 'select id from tags where use_check is null;');
tagIDs=exec(dbConn, 'select id from tags;');%acquire tag IDs
tagIDs1=fetch(tagIDs);
tagIDs2=tagIDs1.Data;

for i=1:length(current2)%for each tag
    i
    currentword=['''' current2{i} ''''];
    questions=exec(dbConn, ['select id from webct where question regexp ',currentword,';']);
   Qfetch=fetch(questions);%find the question IDs containing that tag
    IDs=Qfetch.Data;%and store their IDs
    for k=1:length(IDs)%then for each question
        if isnumeric(IDs{k})==0
            break
        end
       
          old=exec(dbConn, ['select VIP_tags from webct where id=',num2str(IDs{k}),';']);
          oldtags=fetch(old);   %fetch out the old tag IDs
          oldtagIDs=oldtags.Data;
          oldtags=oldtagIDs{1};
            I=tagIDs2{i};
          class(I);
            I=num2str(I);
          exec(dbConn,[ 'update webct set VIP_tags=concat_ws('', '',',oldtags,',',I,') where id=',num2str(IDs{k}),';']);
          %and update the table with the old IDs concatenated with new ones
          
          %%%%%%%% tally up number of uses%%%%%%%%%%%%%%%%%%%
          oldnum=exec(dbConn, ['select num_uses from tags where id=',I,';']);
          oldnums=fetch(oldnum);
          oldusages=oldnums.Data;
                    newusages=oldusages{1}+1;
          newusages=num2str(newusages);
          exec(dbConn, ['update tags set num_uses=',newusages,' where id=',I,';']);
          %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end 
    
end
toc%end stop watch
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%more statistics%%%%%%%%%%%%%%%%
numuses=exec(dbConn, 'select num_uses from tags;');%this
numuses=fetch(numuses);%code
numuses=numuses.Data;%for
numuses=cell2mat(numuses);%presentation
[numuses indx]=sort(numuses);%purposes
orderednames=current2(indx);
length(orderednames)%only
top25={orderednames{(end-24):end}};
orderednames(find(numuses==0))=[];
orderednames(1:24)
length(orderednames)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
else
    disp(sprintf('Connection failed: %s', dbConn.Message));
end

% Close the connection so we don't run out of MySQL threads
close(dbConn);