<?php
$zip = zip_open("test.zip");
zip_read($zip);


zip_close($zip);
?>